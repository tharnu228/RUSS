export interface PartsOfSpeachItemType {
  text: string;
}
