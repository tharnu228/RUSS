export { TemplateForTests } from './ui/TemplateForTests';
export type { CheckButtonOnClickResult } from './ui/TemplateForTests';
