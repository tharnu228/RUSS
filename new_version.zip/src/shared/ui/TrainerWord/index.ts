export { TrainerWord } from './ui/TrainerWord';
