export const isInJest = () => {
  return process.env.NODE_ENV === 'test';
};
