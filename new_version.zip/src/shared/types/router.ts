export type AppRoutes = 'main' | 'notFound' | 'theory';
