export { useWordActions } from './useWordActions';
export type {
  wordActionsFunctionType,
  wordActionsFunctionExtendType,
} from './types/types';
