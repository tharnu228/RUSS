import { PartsOfSpeachItemType } from '@/features/PartsOfSpeachItem';

export interface PartsOfSpeachType {
  theme: string;
  items: PartsOfSpeachItemType[];
}
