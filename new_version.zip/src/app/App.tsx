import { AppRouter } from './providers/router/ui/AppRouter';

export const App = () => {
  return <AppRouter />;
};
