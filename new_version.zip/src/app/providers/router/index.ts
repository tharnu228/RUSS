export { AppRouter } from './ui/AppRouter';
